CREATE DATABASE  IF NOT EXISTS `TravelDreamDB` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `TravelDreamDB`;
-- MySQL dump 10.13  Distrib 5.5.34, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: TravelDreamDB
-- ------------------------------------------------------
-- Server version	5.5.34-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Pacchetto`
--

DROP TABLE IF EXISTS `Pacchetto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pacchetto` (
  `idPacchetto` int(11) NOT NULL AUTO_INCREMENT,
  `pernottamento` int(11) NOT NULL,
  `voloAndata` int(11) NOT NULL,
  `voloRitorno` int(11) NOT NULL,
  `citta` varchar(45) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `descrizione` text NOT NULL,
  `prezzo` decimal(7,2) NOT NULL,
  `tipologia` enum('romantico','avventura','culturale','relax') NOT NULL,
  `target` enum('singolo','coppia','gruppo') NOT NULL,
  `foto1` char(16) DEFAULT NULL,
  `foto2` char(16) DEFAULT NULL,
  `foto3` char(16) DEFAULT NULL,
  `foto4` char(16) DEFAULT NULL,
  `foto5` char(16) DEFAULT NULL,
  `foto6` char(16) DEFAULT NULL,
  `selezionabile` bit(1) NOT NULL,
  PRIMARY KEY (`idPacchetto`),
  UNIQUE KEY `idPacchetto_UNIQUE` (`idPacchetto`),
  KEY `fk_Pacchetto_1_idx` (`pernottamento`),
  KEY `fk_Pacchetto_2_idx` (`voloAndata`),
  KEY `fk_Pacchetto_3_idx` (`voloRitorno`),
  CONSTRAINT `fk_Pacchetto_1` FOREIGN KEY (`pernottamento`) REFERENCES `Pernottamento` (`idPernottamento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Pacchetto_2` FOREIGN KEY (`voloAndata`) REFERENCES `Volo` (`idVolo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Pacchetto_3` FOREIGN KEY (`voloRitorno`) REFERENCES `Volo` (`idVolo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pacchetto`
--

LOCK TABLES `Pacchetto` WRITE;
/*!40000 ALTER TABLE `Pacchetto` DISABLE KEYS */;
INSERT INTO `Pacchetto` VALUES (4,1,251,1075,'New York','Emozioni Newyorkesi','Se avete in programma un viaggio a New York, non perdetevi i neon di Times Square, il viavai di Union Square e i romantici viali alberati di Central Park. Il trendy e artistico quartiere di Brooklyn è un\'altra irrinunciabile meta di New York per chi ha prenotato un viaggio last minute a New York, così come il solenne 9/11 Memorial, che sorge su Ground Zero, un tempo sede del World Trade Center. La Statua della Libertà si erge sul porto, un faro di speranza per milioni di emigranti in fuga da guerra e carestie alla fine del XIX secolo, e continua a simboleggiare la libertà e le infinite possibilità della Grande Mela, che ogni anno attira frotte di sognatori alla ricerca di un nuovo inizio. E i fortunati turisti in viaggio a New York potranno vivere le stesse emozioni una volta sbarcati nella città che non dorme mai.\r\n',2580.00,'romantico','coppia','P1_000000001.jpg','P2_000000001.jpg','P3_000000001.jpg','H1_000000001.jpg','A1_000000001.jpg','A1_000000002.jpg',''),(5,7,4960,5763,'Oslo','Il lato culturale di Oslo','Oslo, importante capitale Europea, ha un\'area metropolitana unica in quanto la città è una combinazione perfetta tra cultura, divertimenti e la natura selvaggia a pochi passi dal centro. Mete da prediligere, oltre ai numerosi musei(imperdibile il Museo dello Sci) e al parco Vigeland, la centralissima via di Karl Joahn ed i pontili di Aker Brygge. Da visitare la Torre del Trampolino con la sua splendida vista su Oslo.\r\n',946.00,'culturale','coppia','P1_000000002.jpg','P2_000000002.jpg','P3_000000002.jpg','H1_000000002.jpg','A1_000000003.jpg','A1_000000004.jpg',''),(7,5,3891,4692,'Venezia','Capodanno Veneziano','Un capodanno a Venezia è ciò che hai sempre sognato? Inaugurare il nuovo anno lungo uno dei pittoreschi canali della laguna più famosa al mondo o partecipare ai tradizionali festeggiamenti in Piazza San Marco? Con TravelDream potrai organizzare il tuo sogno in tutta facilità grazie a questo pacchetto pensato apposta per te!\r\n',2200.00,'relax','gruppo','P1_000000003.jpg','P2_000000003.jpg','P3_000000003.jpg','H1_000000003.jpg','A1_000000005.jpg','A1_000000006.jpg',''),(8,16,6470,7274,'Sydney','Avventure a Sydney','Sydney è la più famosa città australiana e per questo è stata ed è ancor oggi la meta della maggior parte degli immigrati provenienti da ogni parte del Mondo, il che l\'ha resa un baluardo della multiculturalità. Sydney offre panorami affascinanti e ambienti di ogni genere dallo spettacolare centro proiettato verso il cielo con i suoi moderni grattaceli alle lunghe strade dei quartieri residenziali costellati di piccole villette. Sydney è una città sempre in movimento, dalla amichevole frenesia lavorativa delle ore diurne si passa al caotico e trasgressivo rumereggiare notturno. In altre parole, troverai ciò che cerchi!',1780.00,'avventura','gruppo','pSyd1.jpg','pSyd2.jpg','pSyd3.jpg','a1Syd1.jpg','a2Syd1.jpg','hSyd1.jpg','');
/*!40000 ALTER TABLE `Pacchetto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-01-31 10:39:17
