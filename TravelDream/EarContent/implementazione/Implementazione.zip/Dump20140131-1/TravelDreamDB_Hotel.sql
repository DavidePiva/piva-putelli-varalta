CREATE DATABASE  IF NOT EXISTS `TravelDreamDB` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `TravelDreamDB`;
-- MySQL dump 10.13  Distrib 5.5.34, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: TravelDreamDB
-- ------------------------------------------------------
-- Server version	5.5.34-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Hotel`
--

DROP TABLE IF EXISTS `Hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Hotel` (
  `idHotel` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `citta` varchar(45) NOT NULL,
  `indirizzo` varchar(80) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `descrizione` text NOT NULL,
  `selezionabile` bit(1) NOT NULL,
  `foto1` char(16) DEFAULT NULL,
  `foto2` char(16) DEFAULT NULL,
  `foto3` char(16) DEFAULT NULL,
  PRIMARY KEY (`idHotel`),
  UNIQUE KEY `idHotel_UNIQUE` (`idHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Hotel`
--

LOCK TABLES `Hotel` WRITE;
/*!40000 ALTER TABLE `Hotel` DISABLE KEYS */;
INSERT INTO `Hotel` VALUES (1,'Night Hotel Times Square','New York','157 West 47th Street','8008313413','Ubicato in un\'eccellente posizione, a pochi passi da Times Square, questo hotel di Manhattan propone un ristorante con vista incantevole sulla città e camere provviste di comfort moderni, tra cui una TV a schermo piatto. Caratterizzato da un\'atmosfera elegante e artistica, il Night Hotel Times Square offre il servizio di noleggio iPod e l\'accesso gratuito alla rinomata palestra New York Sports Club, sita nelle vicinanze. Il ristorante Aspen Social Club, specializzato in pasti in stile tapas ispirati al Colorado, fornisce anche il servizio in camera.','','H1_000000001.jpg','H2_000000001.jpg','H3_000000001.jpg'),(2,'Thon Hotel Cecil','Oslo','Stortingsgata 8','23314800','Il Thon Hotel Cecil è un hotel business accogliente nel cuore di Oslo, vicino al Parlamento e alla via pedonale Karl Johans gate, dove trovate tutti i tipi di ristoranti, locali e negozi. Ogni mattina, nel salone ben illuminato, viene servito un ottimo e delicato buffet a colazione. La sera, eccetto nei mesi estivi, viene anche servita una cena a buffet leggera.','','H1_000000002.jpg','H2_000000002.jpg','H3_000000002.jpg'),(3,'Hotel Rialto','Venezia','Riva del Ferro 30124','543623482','Situato di fronte al Ponte di Rialto, l\'Hotel Rialto dispone di una terrazza con vista sul Canal Grande e offre camere e suite arredate in stile tradizionale veneziano e dotate di TV satellitare. Durante il vostro soggiorno presso il Rialto potrete gustare una colazione continentale a buffet ammirando le viste sul ponte e sul canale. Le camere e le suite sono tutte provviste di aria condizionata e minibar, e alcune vantano anche affacci sul canale e sul ponte.','','H1_000000003.jpg','H2_000000003.jpg','H3_000000003.jpg'),(29,'Railway Square YHA','Sydney','8-10 Lee St, Haymarket, 2000','4893456734','Ubicato in una posizione invidiabile, accanto alla stazione centrale di Sidney, il Railway Square YHA è ottimamente servito dai mezzi pubblici e offre una piscina all\'aperto, attrezzature per il barbecue e una caffetteria.\r\nPresso il YHA Railway Square potrete gustare colazioni continentali, bevande calde e snack al Parcel Shed Café, e prepararvi da mangiare nella grande cucina comune, completamente attrezzata.\r\nIl relax vi attende nelle aree salotto e pranzo della struttura. Tra i vari servizi troverete una zona lavanderia, oltre a un deposito bagagli custodito e alla biancheria da letto inclusi nella camera.\r\n\r\n\r\n','','hSyd1.jpg','hSyd2.jpg','hSyd3.jpg');
/*!40000 ALTER TABLE `Hotel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-01-31 10:39:17
